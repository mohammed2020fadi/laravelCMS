<?php $__env->startSection('title', 'Categories'); ?>

<?php $__env->startSection('content'); ?>
  <div class="d-flex mb-2 justify-center-end">
    <a href="/category/create" class="btn btn-success">Add Category</a>
  </div>
  <div class="card card-default">
    <div class="card-header">Categories</div>
    <div class="card-body">
      <table class="table">
        <thead>
          <th>Name</th>
        </thead>
        <tbody>
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>
                <?php echo e($category->name); ?>

                <a href="/category/<?php echo e($category->id); ?>/edit" class="btn btn-primary float-right btn-sm">Edit</a>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\cats\cms\resources\views/category/index.blade.php ENDPATH**/ ?>