<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('content'); ?>
  <div class="card card-default">
    <div class="card-header">[ <?php echo e(count($users)); ?> ] Users</div>
    <div class="card-body p-0">
      <?php if(count($users) > 0): ?>
        <table class="table table-striped table-dark">
          <thead>
            <th>Image</th>
            <th>Name</th>
            <th>Email</th>
            <th>Control</th>
          </thead>
          <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>
                  <img src="<?php echo e(Gravatar::src($user->email)); ?>" alt="<?php echo e($user->name); ?>" width="80px" height="80px" class="img-thumbnail">
                </td>
                <td>
                  <?php echo e($user->name); ?>

                </td>
                <td>
                  <?php echo e($user->email); ?>

                </td>
                <td>
                  <?php if(!$user->isAdmin()): ?>
                    <form action="<?php echo e(route('users.make-admin', $user->id)); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <button type="submit" class="btn btn-primary btn-sm">Make Admin</button>
                    </form>
                  <?php else: ?>
                    <?php if(auth()->user()->id == $user->id): ?>
                      <button class="btn btn-success btn-sm disabled" style="cursor: no-drop;">Make Writer</button>
                    <?php else: ?>
                      <form action="<?php echo e(route('users.make-writer', $user->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-success btn-sm">Make Writer</button>
                      </form>
                    <?php endif; ?>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>              
          </tbody>
        </table>
      <?php else: ?>
        <h3 class="text-center my-2">No Users</h3>
      <?php endif; ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\cats\cms\resources\views/users/index.blade.php ENDPATH**/ ?>