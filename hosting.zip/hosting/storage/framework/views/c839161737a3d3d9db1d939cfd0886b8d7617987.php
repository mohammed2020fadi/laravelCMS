<?php $__env->startSection('title', 'Edit User'); ?>

<?php $__env->startSection('content'); ?>
  <div class="card card-default">
    <div class="card-header">
      Edit User
    </div>
    <div class="card-body">
      <form action="<?php echo e(route('users.update', $user->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
          <label for="name">Name :- </label>
          <input id="name" type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>">
        </div>
        <div class="form-group">
          <label for="email">E-mail :- </label>
          <input id="email" type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>">
        </div>
        <div class="form-group">
          <label for="about">About :- </label>
          <textarea class="form-control" name="about" id="about" rows="3"><?php echo e($user->about); ?></textarea>
        </div>
        <div class="form-group">
          <input type="submit" value="Edit User" class="btn btn-primary">
        </div>
      </form>
    </div>
  </div>  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\cats\cms\resources\views/users/edit.blade.php ENDPATH**/ ?>