<?php $__env->startSection('title', 'Tags'); ?>

<?php $__env->startSection('content'); ?>
  <div class="d-flex mb-2 justify-center-end">
  <a href="<?php echo e(route('tags.create')); ?>" class="btn btn-success">Add Tag</a>
  </div>
  <div class="card card-default">
    <div class="card-header">[ <?php echo e(count($tags)); ?> ] Tags</div>
    <div class="card-body p-0">
      <?php if(count($tags) > 0): ?>
        <table class="table table-striped table-dark">
          <thead>
            <th>Name</th>
            <th>Posts</th>
            <th>Control</th>
          </thead>
          <tbody>
            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>
                  <?php echo e($tag->name); ?>

                </td>
                <td>
                  <?php echo e($tag->posts->count()); ?>

                </td>
                <td>
                  <a href="<?php echo e(route('tags.edit', $tag->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                  <form action="<?php echo e(route('tags.destroy', $tag->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm mt-1">Delete</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>              
          </tbody>
        </table>
      <?php else: ?>
        <h3 class="text-center my-2">No Categories</h3>
      <?php endif; ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\cats\cms\resources\views/tags/index.blade.php ENDPATH**/ ?>