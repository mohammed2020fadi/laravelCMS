<?php $__env->startSection('title', 'Posts'); ?>

<?php $__env->startSection('content'); ?>
  <div class="d-flex mb-2 justify-center-end">
    <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-success">Add Post</a>
  </div>
  <div class="card card-default">
    <div class="card-header row">
      <div class="col-md-2">
        [ <?php echo e(count($posts)); ?> ] Posts
      </div>
      <div class="col-md-10">
        <form action="<?php echo e(route('posts.index')); ?>" method="GET">
          <div class="row">
            <div class="col-sm-10">
              <input class="form-control" type="search" name="search" value="<?php echo e(request()->query('search')); ?>">
            </div>
            <div class="col-sm-2">
              <button type="submit" class="btn btn-primary">Search</button>
            </div>
          </div>
        </form>
      </div>
    </div>
    <div class="card-body p-0">
      <?php if(count($posts) > 0): ?>
        <table class="table table-striped table-dark table-responsive-sm">
          <thead>
            <th>Image</th>
            <th>Title</th>
            <th>Category</th>
            <th>Tags</th>
            <th>Control</th>
          </thead>
          <tbody>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>
                  <img src="<?php echo e(asset('storage/'.$post->image)); ?>" width="160" class="img-thumbnail">
                </td>
                <td><?php echo e($post->title); ?></td>
                <td>
                  <?php if(isset($post->category->id)): ?>
                    <a href="<?php echo e(route('categories.edit', $post->category->id)); ?>" style="color:#ddd">
                      <?php echo e($post->Category->name); ?>

                    </a>
                  <?php else: ?>
                    <p style="color:rgb(255, 80, 80)">
                      No Category
                    </p>
                  <?php endif; ?>
                </td>
                <td>
                  <?php if($post->tags->count() > 0): ?>
                    <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <a href="<?php echo e(route('tags.edit', $tag->id)); ?>" class="badge">
                        <?php echo e($tag->name); ?>

                      </a><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                    <p style="color:rgb(255, 80, 80)">
                      No Tag
                    </p>
                  <?php endif; ?>
                </td>
                <td>
                  <?php if($post->trashed()): ?>
                    <form action="<?php echo e(route('restore-post', $post->id)); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('PUT'); ?>
                      <button type="submit" class="btn btn-primary btn-sm mt-1">Restore</button>
                    </form>
                  <?php else: ?>
                    <a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                  <?php endif; ?>
                  <form action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm mt-1">
                      <?php echo e($post->trashed() ? 'Delete' : 'Trach'); ?>

                    </button>
                  </form>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        <div class="justify-content-center row">
          <?php echo e($posts->links()); ?>

        </div>
      <?php else: ?>
        <h3 class="text-center my-2">No Posts</h3>  
      <?php endif; ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\cats\cms\resources\views/posts/index.blade.php ENDPATH**/ ?>