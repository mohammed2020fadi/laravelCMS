<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <title><?php echo $__env->yieldContent('title', 'CMS'); ?></title>
    <!-- Styles -->
    <link href="<?php echo e(asset('css/inc/page.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <!-- Favicons -->
    <link rel="apple-touch-icon" href="<?php echo e(asset('storage/img/apple-touch-icon.png')); ?>">
    <link rel="icon" href="<?php echo e(asset('storage/img/favicon.png')); ?>">
  </head>
  <body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light navbar-stick-dark" data-navbar="sticky">
      <div class="container">

        <div class="navbar-left">
          <button class="navbar-toggler" type="button">&#9776;</button>
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
            <img class="logo-dark" src="storage/img/logo-dark.png" alt="logo">
            <img class="logo-light" src="storage/img/logo-light.png" alt="logo">
          </a>
        </div>

        <section class="navbar-mobile">
          <span class="navbar-divider d-mobile-none"></span>
            <ul class="nav nav-navbar ">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(route('')); ?>"><?php echo e($category->name); ?> </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </section>
      </div>
    </nav><!-- /.navbar -->


    <?php echo $__env->yieldContent('content'); ?>


    <!-- Footer -->
    <footer class="footer">
      <div class="container">
        <div class="row gap-y align-items-center">

          <div class="col-6 col-lg-3">
            <a href="../index.html"><img src="<?php echo e(asset('storage/img/logo-dark.png')); ?>" alt="logo"></a>
          </div>

          <div class="col-6 col-lg-3 text-right order-lg-last">
            <div class="social">
              <a class="social-facebook" href="https://www.facebook.com/thethemeio"><i class="fa fa-facebook"></i></a>
              <a class="social-twitter" href="https://twitter.com/thethemeio"><i class="fa fa-twitter"></i></a>
              <a class="social-instagram" href="https://www.instagram.com/thethemeio/"><i class="fa fa-instagram"></i></a>
              <a class="social-dribbble" href="https://dribbble.com/thethemeio"><i class="fa fa-dribbble"></i></a>
            </div>
          </div>

          <div class="col-lg-6">
            <div class="nav nav-bold nav-uppercase nav-trim justify-content-lg-center">
              <a class="nav-link" href="../uikit/index.html">Elements</a>
              <a class="nav-link" href="../block/index.html">Blocks</a>
              <a class="nav-link" href="../page/about-1.html">About</a>
              <a class="nav-link" href="../blog/grid.html">Blog</a>
              <a class="nav-link" href="../page/contact-1.html">Contact</a>
            </div>
          </div>

        </div>
      </div>
    </footer><!-- /.footer -->
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/inc/js/page.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/inc/js/script.js')); ?>"></script>
  </body>
</html><?php /**PATH C:\xampp\htdocs\laravel\cats\cms\resources\views///layouts/main.blade.php ENDPATH**/ ?>