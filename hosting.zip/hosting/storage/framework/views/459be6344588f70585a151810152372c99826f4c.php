<?php if(isset($category)): ?>
  <?php $__env->startSection('title', 'Update Category'); ?>
<?php else: ?>
  <?php $__env->startSection('title', 'Create Category'); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
  <div class="card card-default">
    <div class="card-header">
      <?php echo e(isset($category) ? 'Edit Category' : 'Create Category'); ?>

    </div>
    <div class="card-body">
      <form action="<?php echo e(isset($category) ? route('categories.update', $category->id) : route('categories.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php if(isset($category)): ?>
          <?php echo method_field('PUT'); ?>
        <?php endif; ?>
        <div class="form-group">
          <label for="name">Category Name :- </label>
          <input id="name" type="text" class="form-control" name="name" value="<?php echo e(isset($category) ? $category->name : ''); ?>">
        </div>
        <div class="form-group">
          <input type="submit" value="<?php echo e(isset($category) ? 'Edit Category' : 'Add Category'); ?>" class="btn btn-primary">
        </div>
      </form>
    </div>
  </div>  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\cats\cms\resources\views/categories/create.blade.php ENDPATH**/ ?>