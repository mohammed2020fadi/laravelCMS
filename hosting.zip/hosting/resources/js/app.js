require('./bootstrap');
require('./select2');
$(document).ready(function () {
  $('.tags-select').select2();
});
